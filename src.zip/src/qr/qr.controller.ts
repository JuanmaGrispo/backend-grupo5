import { Controller } from '@nestjs/common';

@Controller('qr')
export class QrController {}
