import { Controller } from '@nestjs/common';

@Controller('notifier')
export class NotifierController {}
